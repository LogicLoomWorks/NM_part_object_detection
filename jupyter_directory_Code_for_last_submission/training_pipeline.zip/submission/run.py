"""
run.py — NorgesGruppen product detection submission entry point.

Usage:
    python run.py --input /data/images --output /output/predictions.json

Pipeline:
    1. Load YOLOv8x ONNX detector   → find product bounding boxes
    2. Load EfficientNet-B3 ONNX classifier → identify product category
    3. Output COCO-format JSON

All inference uses onnxruntime (no torch, no ultralytics).
No banned imports: uses only pathlib, json, argparse, numpy, cv2, onnxruntime.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List

import cv2
import numpy as np
import onnxruntime as ort

# ── Paths (relative to this file) ─────────────────────────────────────────────
HERE            = Path(__file__).parent
DETECTOR_PATH   = HERE / "detector.onnx"
CLASSIFIER_PATH = HERE / "classifier.onnx"
DET_MAP_PATH    = HERE / "idx_to_category_id.json"
CLS_MAP_PATH    = HERE / "classifier_idx_to_category_id.json"

# ── Inference hyper-params ─────────────────────────────────────────────────────
_SCORE_THRESH = 0.05   # detector confidence threshold (low = more recalls)
_IOU_THRESH   = 0.45   # NMS IoU threshold
_IMG_SIZE     = 640    # detector input resolution — must match 03_train_detector.py
_CLS_SIZE     = 224    # classifier input resolution — must match 05_train_classifier.py

# ImageNet normalization (must match 05_train_classifier.py)
_MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
_STD  = np.array([0.229, 0.224, 0.225], dtype=np.float32)


# ── Pre-processing helpers ─────────────────────────────────────────────────────

def preprocess_detector(bgr: np.ndarray, size: int = _IMG_SIZE):
    """
    Letterbox-resize BGR image to (size, size), convert to float32 RGB NCHW.
    Places image at top-left of canvas (no centering) — scale is the only transform.
    Returns (tensor, scale, padded_h, padded_w).
    """
    h, w    = bgr.shape[:2]
    scale   = size / max(h, w)
    nh, nw  = int(h * scale), int(w * scale)
    resized = cv2.resize(bgr, (nw, nh), interpolation=cv2.INTER_LINEAR)
    canvas  = np.full((size, size, 3), 114, dtype=np.uint8)
    canvas[:nh, :nw] = resized
    rgb    = canvas[:, :, ::-1].astype(np.float32) / 255.0
    tensor = rgb.transpose(2, 0, 1)[np.newaxis]   # (1, 3, H, W)
    return tensor, scale, nh, nw


def preprocess_crop(bgr_crop: np.ndarray, size: int = _CLS_SIZE) -> np.ndarray:
    """Resize crop to (size, size), apply ImageNet normalisation, return NCHW."""
    resized = cv2.resize(bgr_crop, (size, size), interpolation=cv2.INTER_LINEAR)
    rgb     = resized[:, :, ::-1].astype(np.float32) / 255.0
    rgb     = (rgb - _MEAN) / _STD
    return rgb.transpose(2, 0, 1)[np.newaxis].astype(np.float32)


# ── NMS (pure numpy) ──────────────────────────────────────────────────────────

def nms(boxes: np.ndarray, scores: np.ndarray, iou_thresh: float) -> List[int]:
    """
    Non-maximum suppression.
    boxes  : (N, 4)  in xyxy format
    scores : (N,)
    Returns list of kept indices.
    """
    x1 = boxes[:, 0]; y1 = boxes[:, 1]
    x2 = boxes[:, 2]; y2 = boxes[:, 3]
    areas = (x2 - x1) * (y2 - y1)
    order = scores.argsort()[::-1]
    keep  = []
    while order.size > 0:
        i = order[0]
        keep.append(int(i))
        if order.size == 1:
            break
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])
        inter_w = np.maximum(0.0, xx2 - xx1)
        inter_h = np.maximum(0.0, yy2 - yy1)
        inter   = inter_w * inter_h
        iou     = inter / (areas[i] + areas[order[1:]] - inter + 1e-6)
        order   = order[1:][iou <= iou_thresh]
    return keep


# ── Main inference ─────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="NorgesGruppen product detection — ONNX inference"
    )
    parser.add_argument("--input",  required=True,  help="Directory of .jpg images")
    parser.add_argument("--output", required=True,  help="Output predictions.json path")
    args = parser.parse_args()

    input_dir   = Path(args.input)
    output_path = Path(args.output)

    # ── Load category mappings ─────────────────────────────────────────────
    det_map: Dict[str, int] = json.loads(DET_MAP_PATH.read_text(encoding="utf-8"))
    cls_map: Dict[str, int] = json.loads(CLS_MAP_PATH.read_text(encoding="utf-8"))

    # ── Build ONNX sessions ────────────────────────────────────────────────
    providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]
    det_sess  = ort.InferenceSession(str(DETECTOR_PATH),   providers=providers)
    cls_sess  = ort.InferenceSession(str(CLASSIFIER_PATH), providers=providers)

    det_in_name = det_sess.get_inputs()[0].name
    cls_in_name = cls_sess.get_inputs()[0].name

    # ── Collect image files ────────────────────────────────────────────────
    image_paths = sorted(
        p for p in input_dir.iterdir()
        if p.suffix.lower() in {".jpg", ".jpeg"}
    )
    print(f"Found {len(image_paths)} images in {input_dir}")

    results: List[Dict] = []

    for img_path in image_paths:
        # Parse image_id: img_00042.jpg → 42
        try:
            image_id = int(img_path.stem.split("_")[1])
        except (IndexError, ValueError):
            digits   = "".join(c for c in img_path.stem if c.isdigit())
            image_id = int(digits) if digits else 0

        bgr = cv2.imread(str(img_path))
        if bgr is None:
            print(f"  WARNING: could not read {img_path.name}")
            continue

        orig_h, orig_w = bgr.shape[:2]

        # ── Detection ─────────────────────────────────────────────────────
        tensor, scale, nh, nw = preprocess_detector(bgr, _IMG_SIZE)
        det_out = det_sess.run(None, {det_in_name: tensor})[0]

        # YOLOv8 ONNX output shape: (1, 4+nc, num_anchors)
        # Transpose to (num_anchors, 4+nc)
        preds        = det_out[0].T             # (N, 4+nc)
        boxes_cxcywh = preds[:, :4]
        class_scores = preds[:, 4:]
        scores       = class_scores.max(axis=1)
        class_ids    = class_scores.argmax(axis=1)

        mask = scores > _SCORE_THRESH
        if not mask.any():
            continue

        boxes_f  = boxes_cxcywh[mask]
        scores_f = scores[mask]
        cids_f   = class_ids[mask]

        # Convert cx/cy/w/h (canvas space) → x1/y1/x2/y2 (original pixel coords)
        # Image placed at top-left of canvas → only scale transform needed
        cx = boxes_f[:, 0] / scale
        cy = boxes_f[:, 1] / scale
        bw = boxes_f[:, 2] / scale
        bh = boxes_f[:, 3] / scale
        x1 = np.clip(cx - bw / 2, 0, orig_w)
        y1 = np.clip(cy - bh / 2, 0, orig_h)
        x2 = np.clip(cx + bw / 2, 0, orig_w)
        y2 = np.clip(cy + bh / 2, 0, orig_h)
        xyxy = np.stack([x1, y1, x2, y2], axis=1)

        keep = nms(xyxy, scores_f, _IOU_THRESH)
        if not keep:
            continue

        for i in keep:
            xi1, yi1, xi2, yi2 = xyxy[i]
            bw_px = xi2 - xi1
            bh_px = yi2 - yi1
            if bw_px <= 0 or bh_px <= 0:
                continue

            # ── Classification ─────────────────────────────────────────────
            crop = bgr[int(yi1):int(yi2), int(xi1):int(xi2)]
            if crop.size == 0:
                continue

            cls_input = preprocess_crop(crop, _CLS_SIZE)
            cls_out   = cls_sess.run(None, {cls_in_name: cls_input})[0]
            cls_idx   = int(cls_out[0].argmax())
            category_id = int(cls_map.get(str(cls_idx), 0))

            results.append({
                "image_id":    image_id,
                "category_id": category_id,
                "bbox": [
                    float(xi1),
                    float(yi1),
                    float(bw_px),
                    float(bh_px),
                ],
                "score": float(scores_f[i]),
            })

    # ── Write output ───────────────────────────────────────────────────────
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(results, indent=2), encoding="utf-8"
    )
    print(f"Wrote {len(results)} predictions → {output_path}")


if __name__ == "__main__":
    main()
