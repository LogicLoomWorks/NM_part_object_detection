"""
01_data_exploration.py — Investigate all data sources before training.

Usage:
    python 01_data_exploration.py

Prints a summary of:
  - coco_dataset (images, annotations, categories, class distribution)
  - SKU110K_fixed (CSV format, image counts)
  - aug_product_images (folder structure, annotation presence)
  - product_images (folder count, image count)
"""
import json
from collections import defaultdict, Counter
from pathlib import Path

# ── Paths ─────────────────────────────────────────────────────────────────────
COCO_DIR    = Path("data/raw/coco_dataset/train")
ANN_FILE    = COCO_DIR / "annotations.json"
IMG_DIR     = COCO_DIR / "images"

SKU110K_DIR = Path("data/raw/extra_data/SKU110K_fixed")
SKU_ANN_DIR = SKU110K_DIR / "annotations"
SKU_IMG_DIR = SKU110K_DIR / "images"

AUG_DIR     = Path("data/augmented_data/aug_product_images")
PROD_DIR    = Path("data/raw/product_images")

BANNER = "=" * 60

# ══════════════════════════════════════════════════════════════════════════════
# 1. COCO DATASET
# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{BANNER}")
print("  1. COCO DATASET")
print(BANNER)

if not ANN_FILE.exists():
    print(f"  ERROR: {ANN_FILE} not found")
else:
    data        = json.loads(ANN_FILE.read_text(encoding="utf-8"))
    images      = data["images"]
    annotations = data["annotations"]
    categories  = sorted(data["categories"], key=lambda c: c["id"])

    n_imgs  = len(images)
    n_anns  = len(annotations)
    n_cats  = len(categories)
    cat_ids = [c["id"] for c in categories]
    id_min, id_max = min(cat_ids), max(cat_ids)

    # Check for gaps
    full_range = set(range(id_min, id_max + 1))
    gaps = sorted(full_range - set(cat_ids))

    # Annotations per image
    ann_by_img = defaultdict(list)
    for a in annotations:
        ann_by_img[a["image_id"]].append(a)
    anns_per_img = [len(v) for v in ann_by_img.values()]
    avg_anns = sum(anns_per_img) / len(anns_per_img) if anns_per_img else 0

    # Images with no annotations
    all_img_ids = {im["id"] for im in images}
    imgs_no_ann = all_img_ids - set(ann_by_img.keys())

    # Image sizes
    widths  = [im["width"]  for im in images if "width"  in im]
    heights = [im["height"] for im in images if "height" in im]

    print(f"  Images      : {n_imgs}")
    print(f"  Annotations : {n_anns}")
    print(f"  Categories  : {n_cats}  (IDs {id_min}–{id_max})")
    print(f"  ID gaps     : {gaps[:10] if gaps else 'none'}")
    print(f"  Images with no annotations: {len(imgs_no_ann)}")
    print(f"  Avg annotations/image: {avg_anns:.1f}")
    if widths:
        print(f"  Width  range: {min(widths)}–{max(widths)} px  avg={sum(widths)//len(widths)}")
        print(f"  Height range: {min(heights)}–{max(heights)} px  avg={sum(heights)//len(heights)}")

    # Class distribution
    ann_per_cat = Counter(a["category_id"] for a in annotations)
    cat_name = {c["id"]: c["name"] for c in categories}
    zero_ann = [c["id"] for c in categories if ann_per_cat.get(c["id"], 0) == 0]

    print(f"\n  Top 10 most common categories:")
    for cid, cnt in ann_per_cat.most_common(10):
        print(f"    [{cid:4d}] {cnt:6d}  {cat_name.get(cid, '?')[:50]}")

    print(f"\n  Bottom 10 least common categories:")
    for cid, cnt in ann_per_cat.most_common()[:-11:-1]:
        print(f"    [{cid:4d}] {cnt:6d}  {cat_name.get(cid, '?')[:50]}")

    print(f"\n  Categories with 0 annotations: {len(zero_ann)}")
    if zero_ann:
        print(f"  IDs: {zero_ann[:20]}")

    # Degenerate boxes
    degen = [a for a in annotations if a["bbox"][2] <= 0 or a["bbox"][3] <= 0]
    print(f"  Degenerate boxes (w<=0 or h<=0): {len(degen)}")

    # Count image files on disk
    if IMG_DIR.exists():
        disk_imgs = list(IMG_DIR.glob("*.jpg")) + list(IMG_DIR.glob("*.jpeg"))
        print(f"\n  Images on disk : {len(disk_imgs)}")
        missing = [im["file_name"] for im in images if not (IMG_DIR / im["file_name"]).exists()]
        print(f"  Missing files  : {len(missing)}")
    else:
        print(f"\n  WARNING: images dir not found: {IMG_DIR}")

    print(f"\n  Sample category names:")
    for c in categories[:8]:
        print(f"    [{c['id']:4d}] {c['name']}")


# ══════════════════════════════════════════════════════════════════════════════
# 2. SKU110K
# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{BANNER}")
print("  2. SKU110K_fixed")
print(BANNER)

sku_counts = {}
for split in ("train", "val", "test"):
    csv_path = SKU_ANN_DIR / f"annotations_{split}.csv"
    if csv_path.exists():
        lines = csv_path.read_text(encoding="utf-8").splitlines()
        header = lines[0] if lines else ""
        n_rows = len(lines) - 1
        unique_imgs = set()
        for line in lines[1:]:
            parts = line.split(",")
            if parts:
                unique_imgs.add(parts[0])
        sku_counts[split] = (n_rows, len(unique_imgs))
        print(f"  {split} CSV columns: {header}")
        print(f"  {split}: {len(unique_imgs)} images, {n_rows} annotations")
        print(f"  First 3 rows:")
        for row in lines[1:4]:
            print(f"    {row}")
        print()
    else:
        print(f"  WARNING: {csv_path} not found")
        sku_counts[split] = (0, 0)

sku_total_imgs = sum(v[1] for v in sku_counts.values())
print(f"  Total SKU110K images: {sku_total_imgs}")

if SKU_IMG_DIR.exists():
    sku_disk = list(SKU_IMG_DIR.glob("*.jpg")) + list(SKU_IMG_DIR.glob("*.jpeg"))
    print(f"  SKU110K images on disk: {len(sku_disk)}")
    if sku_disk:
        print(f"  Sample filename: {sku_disk[0].name}")
else:
    print(f"  WARNING: SKU110K images dir not found: {SKU_IMG_DIR}")


# ══════════════════════════════════════════════════════════════════════════════
# 3. AUG_PRODUCT_IMAGES
# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{BANNER}")
print("  3. aug_product_images")
print(BANNER)

if not AUG_DIR.exists():
    print(f"  WARNING: {AUG_DIR} not found")
    aug_cats = 0
    aug_total = 0
    aug_has_bbox = False
else:
    subdirs = [d for d in AUG_DIR.iterdir() if d.is_dir()]
    aug_files_direct = (
        list(AUG_DIR.glob("*.jpg")) +
        list(AUG_DIR.glob("*.jpeg")) +
        list(AUG_DIR.glob("*.png"))
    )

    print(f"  Subfolders (categories): {len(subdirs)}")
    if subdirs:
        print(f"  Sample folder names: {[d.name for d in subdirs[:5]]}")

    if subdirs:
        aug_total = sum(
            len(list(d.glob("*.jpg"))) +
            len(list(d.glob("*.jpeg"))) +
            len(list(d.glob("*.png")))
            for d in subdirs
        )
    else:
        aug_total = len(aug_files_direct)
    aug_cats = len(subdirs)

    print(f"  Total images: {aug_total}")
    print(f"  Direct images (non-subfolder): {len(aug_files_direct)}")

    ann_files = (
        list(AUG_DIR.glob("*.json")) +
        list(AUG_DIR.glob("*.csv")) +
        list(AUG_DIR.glob("*.txt"))
    )
    aug_has_bbox = len(ann_files) > 0
    print(f"  Annotation files: {[f.name for f in ann_files] if ann_files else 'NONE'}")


# ══════════════════════════════════════════════════════════════════════════════
# 4. PRODUCT_IMAGES
# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{BANNER}")
print("  4. product_images")
print(BANNER)

if not PROD_DIR.exists():
    print(f"  WARNING: {PROD_DIR} not found")
    prod_folders = 0
    prod_total   = 0
else:
    prod_subdirs = [d for d in PROD_DIR.iterdir() if d.is_dir()]
    prod_folders = len(prod_subdirs)

    imgs_per_folder = []
    prod_total = 0
    for d in prod_subdirs:
        n = (
            len(list(d.glob("*.jpg"))) +
            len(list(d.glob("*.jpeg"))) +
            len(list(d.glob("*.png")))
        )
        imgs_per_folder.append(n)
        prod_total += n

    avg_per_folder = sum(imgs_per_folder) / prod_folders if prod_folders else 0

    print(f"  Product folders  : {prod_folders}")
    print(f"  Total images     : {prod_total}")
    print(f"  Avg images/folder: {avg_per_folder:.1f}")
    if imgs_per_folder:
        print(f"  Min/Max images/folder: {min(imgs_per_folder)} / {max(imgs_per_folder)}")
    print(f"  Sample folder names: {[d.name for d in prod_subdirs[:8]]}")

    if ANN_FILE.exists():
        data2      = json.loads(ANN_FILE.read_text(encoding="utf-8"))
        cat_names2 = {c["name"].lower(): c["id"] for c in data2["categories"]}
        cat_ids_s  = {str(c["id"]): c["id"] for c in data2["categories"]}
        matched = sum(
            1 for d in prod_subdirs
            if d.name.lower() in cat_names2 or d.name in cat_ids_s
        )
        print(f"  Folders matching COCO categories: {matched}/{prod_folders}")


# ══════════════════════════════════════════════════════════════════════════════
# SUMMARY
# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{'═'*60}")
print("  DATA SUMMARY")
print(f"{'═'*60}")

try:
    d = json.loads(ANN_FILE.read_text(encoding="utf-8"))
    print(f"  coco_dataset:    {len(d['images'])} images, "
          f"{len(d['annotations'])} annotations, "
          f"{len(d['categories'])} categories")
except Exception:
    print("  coco_dataset:    ERROR reading")

sku_train = sku_counts.get("train", (0, 0))[1]
sku_val   = sku_counts.get("val",   (0, 0))[1]
sku_test  = sku_counts.get("test",  (0, 0))[1]
print(f"  SKU110K:         {sku_train} train / {sku_val} val / {sku_test} test images")
print(f"  aug_product:     {aug_total} images, {aug_cats} category folders")
print(f"  product_images:  {prod_folders} folders, {prod_total} total images")
print(f"{'═'*60}\n")
print("Next: python 02_prepare_detection_data.py")
