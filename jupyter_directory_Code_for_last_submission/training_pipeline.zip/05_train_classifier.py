"""
05_train_classifier.py — Train EfficientNet-B3 image classifier on cropped product images.

Uses timm 0.9.12, exports to ONNX opset 17.

Usage:
    python 05_train_classifier.py

Outputs:
    submission/classifier.onnx
    submission/classifier_idx_to_category_id.json
"""
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

import timm

# ── Config ────────────────────────────────────────────────────────────────────
DATA_DIR    = Path("data/classifier")
SUBMISSION  = Path("submission")
OUT_ONNX    = SUBMISSION / "classifier.onnx"
OUT_MAP     = SUBMISSION / "classifier_idx_to_category_id.json"

MODEL_NAME   = "efficientnet_b3"
IMG_SIZE     = 224
BATCH_TRAIN  = 128    # H100 can handle it
BATCH_VAL    = 256
EPOCHS       = 20
LR           = 3e-4
WEIGHT_DECAY = 1e-4
NUM_WORKERS  = 8
DEVICE       = "cuda" if torch.cuda.is_available() else "cpu"
SEED         = 42

SUBMISSION.mkdir(exist_ok=True)
torch.manual_seed(SEED)

# ── Verify dataset ────────────────────────────────────────────────────────────
if not (DATA_DIR / "train").exists():
    print(f"ERROR: {DATA_DIR / 'train'} not found.")
    print("Run: python 04_prepare_classification_data.py  first.")
    raise SystemExit(1)

print("=" * 60)
print("  CLASSIFIER TRAINING — EfficientNet-B3")
print("=" * 60)
print(f"  Device : {DEVICE}")
if DEVICE == "cuda":
    print(f"  GPU    : {torch.cuda.get_device_name(0)}")

# ── Data transforms ───────────────────────────────────────────────────────────
# ImageNet mean/std — must match run.py preprocessing exactly
_MEAN = [0.485, 0.456, 0.406]
_STD  = [0.229, 0.224, 0.225]

train_tf = transforms.Compose([
    transforms.RandomResizedCrop(IMG_SIZE, scale=(0.6, 1.0)),
    transforms.RandomHorizontalFlip(),
    transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.3, hue=0.05),
    transforms.RandomGrayscale(p=0.05),
    transforms.ToTensor(),
    transforms.Normalize(_MEAN, _STD),
])

val_tf = transforms.Compose([
    transforms.Resize(int(IMG_SIZE * 1.15)),
    transforms.CenterCrop(IMG_SIZE),
    transforms.ToTensor(),
    transforms.Normalize(_MEAN, _STD),
])

train_ds = datasets.ImageFolder(str(DATA_DIR / "train"), transform=train_tf)
val_ds   = datasets.ImageFolder(str(DATA_DIR / "val"),   transform=val_tf)
n_classes = len(train_ds.classes)

print(f"  Train  : {len(train_ds)} images, {n_classes} classes")
print(f"  Val    : {len(val_ds)} images")

train_loader = DataLoader(
    train_ds, batch_size=BATCH_TRAIN, shuffle=True,
    num_workers=NUM_WORKERS, pin_memory=True, drop_last=True,
)
val_loader = DataLoader(
    val_ds, batch_size=BATCH_VAL, shuffle=False,
    num_workers=NUM_WORKERS, pin_memory=True,
)

# ── Build model ───────────────────────────────────────────────────────────────
print(f"\nBuilding {MODEL_NAME} with {n_classes} output classes ...")
model = timm.create_model(
    MODEL_NAME,
    pretrained=True,
    num_classes=n_classes,
)
model = model.to(DEVICE)

# Label smoothing helps with noisy product labels
criterion = nn.CrossEntropyLoss(label_smoothing=0.1)

optimizer = optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)

# OneCycleLR for fast convergence
scheduler = optim.lr_scheduler.OneCycleLR(
    optimizer,
    max_lr=LR,
    steps_per_epoch=len(train_loader),
    epochs=EPOCHS,
    pct_start=0.1,
)

# Mixed precision
scaler = torch.cuda.amp.GradScaler(enabled=(DEVICE == "cuda"))

# ── Training loop ─────────────────────────────────────────────────────────────
print(f"\nStarting training ({EPOCHS} epochs) ...")
print(f"  Batch train={BATCH_TRAIN}, val={BATCH_VAL}, lr={LR}")
print()

best_val_acc = 0.0
best_ckpt    = Path("runs/classifier_best.pt")
best_ckpt.parent.mkdir(exist_ok=True)

t_start = time.time()

for epoch in range(1, EPOCHS + 1):
    # ── Train ──────────────────────────────────────────────────────────────
    model.train()
    running_loss    = 0.0
    running_correct = 0
    running_total   = 0

    for imgs, labels in train_loader:
        imgs   = imgs.to(DEVICE, non_blocking=True)
        labels = labels.to(DEVICE, non_blocking=True)

        optimizer.zero_grad(set_to_none=True)
        with torch.cuda.amp.autocast(enabled=(DEVICE == "cuda")):
            out  = model(imgs)
            loss = criterion(out, labels)

        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        scheduler.step()

        running_loss    += loss.item() * imgs.size(0)
        preds            = out.argmax(dim=1)
        running_correct += (preds == labels).sum().item()
        running_total   += imgs.size(0)

    train_loss = running_loss / running_total
    train_acc  = running_correct / running_total

    # ── Val ────────────────────────────────────────────────────────────────
    model.eval()
    val_correct  = 0
    val_total    = 0
    top5_correct = 0

    with torch.no_grad():
        for imgs, labels in val_loader:
            imgs   = imgs.to(DEVICE, non_blocking=True)
            labels = labels.to(DEVICE, non_blocking=True)
            with torch.cuda.amp.autocast(enabled=(DEVICE == "cuda")):
                out = model(imgs)
            preds = out.argmax(dim=1)
            val_correct  += (preds == labels).sum().item()
            val_total    += imgs.size(0)
            top5 = out.topk(min(5, n_classes), dim=1).indices
            top5_correct += (top5 == labels.unsqueeze(1)).any(dim=1).sum().item()

    val_acc  = val_correct  / val_total if val_total else 0
    val_top5 = top5_correct / val_total if val_total else 0

    elapsed = time.time() - t_start
    print(
        f"  Epoch {epoch:3d}/{EPOCHS}  "
        f"loss={train_loss:.4f}  train_acc={train_acc:.3f}  "
        f"val_top1={val_acc:.3f}  val_top5={val_top5:.3f}  "
        f"[{elapsed:.0f}s]"
    )

    if val_acc > best_val_acc:
        best_val_acc = val_acc
        torch.save(model.state_dict(), str(best_ckpt))
        print(f"    ↑ New best! Saved to {best_ckpt}")

print(f"\n  Best val accuracy: {best_val_acc:.3f}")
if best_val_acc < 0.20:
    print("  WARNING: val accuracy < 20%. Consider running more epochs or checking data.")

# ── Load best weights ─────────────────────────────────────────────────────────
model.load_state_dict(torch.load(str(best_ckpt), map_location=DEVICE))
model.eval()

# ── Export to ONNX ────────────────────────────────────────────────────────────
print(f"\nExporting to ONNX (opset 17) ...")

dummy = torch.zeros(1, 3, IMG_SIZE, IMG_SIZE, device=DEVICE)

torch.onnx.export(
    model,
    dummy,
    str(OUT_ONNX),
    opset_version=17,
    input_names=["images"],
    output_names=["logits"],
    dynamic_axes=None,         # fixed batch=1 for fast inference
    do_constant_folding=True,
)
print(f"  Exported → {OUT_ONNX}  ({OUT_ONNX.stat().st_size/1024**2:.1f} MB)")

# ── Write classifier_idx_to_category_id.json ─────────────────────────────────
# ImageFolder sorts class folders alphabetically.
# Build: imagefolder_idx (0-based alphabetical) → coco_cat_id
src_map = DATA_DIR / "classifier_idx_to_category_id.json"
if src_map.exists():
    raw_map = json.loads(src_map.read_text(encoding="utf-8"))

    folder_to_coco = {}
    for folder_name, if_idx in train_ds.class_to_idx.items():
        coco_cid = raw_map.get(folder_name)
        if coco_cid is not None:
            folder_to_coco[str(if_idx)] = int(coco_cid)
        else:
            folder_to_coco[str(if_idx)] = 0

    OUT_MAP.write_text(json.dumps(folder_to_coco, indent=2), encoding="utf-8")
    print(f"  Wrote {OUT_MAP}")
else:
    fallback = {str(i): i for i in range(n_classes)}
    OUT_MAP.write_text(json.dumps(fallback, indent=2), encoding="utf-8")
    print(f"  WARNING: {src_map} not found — wrote identity mapping")

total_elapsed = time.time() - t_start
print(f"\n{'='*60}")
print(f"  DONE — {total_elapsed/60:.1f} minutes total")
print(f"  Best val accuracy: {best_val_acc:.3f}")
print(f"\nNext: python 06_build_submission.py")
print(f"{'='*60}")
