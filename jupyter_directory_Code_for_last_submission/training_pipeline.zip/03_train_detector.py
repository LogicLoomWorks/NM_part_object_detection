"""
03_train_detector.py — Train YOLOv8x on COCO+SKU110K, then export to ONNX.

Designed for H100 NVL (94 GB VRAM). Uses batch=16, imgsz=1280, epochs=80.
Higher resolution (1280) captures fine product detail and improves mAP.

Usage:
    python 03_train_detector.py

Outputs:
    runs/detect/nm_yolov8x/weights/best.pt
    submission/detector.onnx
    submission/idx_to_category_id.json
"""
import json
import time
from pathlib import Path

# ── Config ────────────────────────────────────────────────────────────────────
DATA_YAML  = str(Path("data/yolo_detection/dataset.yaml").resolve())
WEIGHTS    = "yolov8x.pt"       # downloaded by ultralytics on first run
RUN_DIR    = Path("runs/detect")
RUN_NAME   = "nm_yolov8x"
SUBMISSION = Path("submission")
OUT_ONNX   = SUBMISSION / "detector.onnx"
OUT_MAP    = SUBMISSION / "idx_to_category_id.json"

# ── Key hyperparams ────────────────────────────────────────────────────────────
EPOCHS    = 80
BATCH     = 32      # 640×640 — H100 94 GB handles batch=32 comfortably
IMG_SIZE  = 640     # faster training, still strong detection quality
PATIENCE  = 20
WORKERS   = 8
DEVICE    = 0       # first GPU

SUBMISSION.mkdir(exist_ok=True)

# ── Verify dataset ─────────────────────────────────────────────────────────────
if not Path(DATA_YAML).exists():
    print(f"ERROR: {DATA_YAML} not found.")
    print("Run: python 02_prepare_detection_data.py  first.")
    raise SystemExit(1)

print("=" * 60)
print("  DETECTOR TRAINING — YOLOv8x @ 640×640")
print("=" * 60)
print(f"  Data    : {DATA_YAML}")
print(f"  Weights : {WEIGHTS}")
print(f"  Epochs  : {EPOCHS}, Batch={BATCH}, ImgSz={IMG_SIZE}")
print(f"  Device  : cuda:{DEVICE}")
print()

from ultralytics import YOLO  # noqa: E402

model = YOLO(WEIGHTS)

t0 = time.time()
results = model.train(
    data          = DATA_YAML,
    epochs        = EPOCHS,
    imgsz         = IMG_SIZE,
    batch         = BATCH,
    device        = DEVICE,
    workers       = WORKERS,
    patience      = PATIENCE,
    save          = True,
    project       = str(RUN_DIR),
    name          = RUN_NAME,
    exist_ok      = True,
    # Optimizer
    optimizer     = "AdamW",
    lr0           = 0.001,
    lrf           = 0.01,
    warmup_epochs = 3,
    # Augmentation
    hsv_h         = 0.015,
    hsv_s         = 0.7,
    hsv_v         = 0.4,
    fliplr        = 0.5,
    flipud        = 0.0,
    mosaic        = 1.0,
    mixup         = 0.15,
    copy_paste    = 0.1,
    close_mosaic  = 10,
    # Misc
    val           = True,
    plots         = True,
    amp           = True,   # mixed precision for H100
)
elapsed = time.time() - t0
print(f"\nTraining complete in {elapsed/60:.1f} minutes")

try:
    m = results.results_dict
    map50   = m.get("metrics/mAP50(B)",    m.get("metrics/mAP50",    "N/A"))
    map5095 = m.get("metrics/mAP50-95(B)", m.get("metrics/mAP50-95", "N/A"))
    print(f"  Best mAP@0.5      : {map50}")
    print(f"  Best mAP@0.5:0.95 : {map5095}")
except Exception as e:
    print(f"  (Could not extract metrics: {e})")

# ── Locate best checkpoint ────────────────────────────────────────────────────
best_pt = RUN_DIR / RUN_NAME / "weights" / "best.pt"
if not best_pt.exists():
    print(f"ERROR: best.pt not found at {best_pt}")
    raise SystemExit(1)

print(f"\n  best.pt found: {best_pt}  ({best_pt.stat().st_size/1024**2:.1f} MB)")

# ── Export to ONNX (opset 17, same imgsz as training) ─────────────────────────
print(f"\nExporting to ONNX (opset 17, imgsz={IMG_SIZE}) ...")
export_model = YOLO(str(best_pt))
export_path  = export_model.export(
    format   = "onnx",
    opset    = 17,
    imgsz    = IMG_SIZE,
    dynamic  = False,   # fixed shapes for onnxruntime
    half     = False,   # fp32 for ort compatibility
    simplify = True,
)
print(f"  ONNX exported to: {export_path}")

# Copy to submission/
onnx_src = Path(str(export_path)) if export_path else None
if onnx_src and onnx_src.exists():
    OUT_ONNX.write_bytes(onnx_src.read_bytes())
    print(f"  Copied → {OUT_ONNX}  ({OUT_ONNX.stat().st_size/1024**2:.1f} MB)")
else:
    # ultralytics sometimes returns None — look for it next to best.pt
    candidate = best_pt.parent / "best.onnx"
    if candidate.exists():
        OUT_ONNX.write_bytes(candidate.read_bytes())
        print(f"  Copied → {OUT_ONNX}")
    else:
        print(f"  WARNING: ONNX file not found, check {best_pt.parent}")

# ── Copy category map ─────────────────────────────────────────────────────────
src_map = Path("data/yolo_detection/idx_to_category_id.json")
if src_map.exists():
    OUT_MAP.write_bytes(src_map.read_bytes())
    print(f"  Copied category map → {OUT_MAP}")
else:
    print(f"  WARNING: {src_map} not found")

print(f"\n{'='*60}")
print("  DONE — Next: python 04_prepare_classification_data.py")
print(f"{'='*60}")
